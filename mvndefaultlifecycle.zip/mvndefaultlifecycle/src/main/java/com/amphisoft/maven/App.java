package com.amphisoft.maven;
public class App {
    public static void main(String[] args) {
        System.out.println(obtainWelcomeString());
    }
    public static String obtainWelcomeString() {
		return "Hello Karthick. Welcome to maven!!!";
	}
}
